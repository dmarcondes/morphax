#Functions to train (continuous) Morphological Neural Networks
import jax
import jax.numpy as jnp
import optax
from alive_progress import alive_bar
import math
import time
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import pickle
from morphax import morph as mp
from morphax import dmorph_jax as dmp
import sys
import itertools
from jax.scipy.stats import rankdata
import copy
from functools import partial
from quadax import quadgk

__docformat__ = "numpy"

#Create an index array for an array
def index_array(shape):
    """
    Create a 2D JAX array with the indexes of an array with given 2D shape.
    -------
    Parameters
    ----------
    shape : list

        List with shape of 2D array

    Returns
    -------
    jax.numpy.array
    """
    return jnp.array([[x,y] for x in range(shape[0]) for y in range(shape[1])])

#MSE
@jax.jit
def MSE(pred,true):
    """
    Mean square error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    Returns
    -------
    mean square error
    """
    return jnp.mean((true - pred)**2)

#MSE self-adaptative
@jax.jit
def MSE_SA(pred,true,wheight,c = 100,q = 2):
    """
    Selft-adaptative mean square error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    wheight : jax.numpy.array

        A JAX numpy array with the weights

    c,q : float

        Hyperparameters

    Returns
    -------
    self-adaptative mean square error
    """
    return jnp.mean(c * (wheight ** q) * (true - pred)**2)

#L2 error
@jax.jit
def L2error(pred,true):
    """
    L2 error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    Returns
    -------
    L2 error
    """
    return jnp.sqrt(jnp.sum((true - pred)**2))/jnp.sqrt(jnp.sum(true ** 2))

#Croos entropy
@jax.jit
def CE(pred,true):
    """
    Cross entropy error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    Returns
    -------
    cross-entropy error
    """
    return jnp.mean((- true * jnp.log(pred + 1e-6) - (1 - true) * jnp.log(1 - pred + 1e-6)))

#Croos entropy self-adaptative
@jax.jit
def CE_SA(pred,true,wheight,c = 100,q = 2):
    """
    Self-adaptative cross entropy error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    wheight : jax.numpy.array

        A JAX numpy array with the weights

    c,q : float

        Hyperparameters

    Returns
    -------
    self-adaptative cross-entropy error
    """
    return jnp.mean(c * (wheight ** q) * (- true * jnp.log(pred + 1e-5) - (1 - true) * jnp.log(1 - pred + 1e-5)))

#IoU
@jax.jit
def IoU(pred,true):
    """
    Intersection over union error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    Returns
    -------
    intersection over union error
    """
    return 1 - (jnp.sum(2 * true * pred) + 1)/(jnp.sum(true + pred) + 1)

#IoU self-adaptative
@jax.jit
def IoU_SA(pred,true,wheight,c = 100,q = 2):
    """
    Selft-adaptative intersection over union error
    ----------
    Parameters
    ----------
    pred : jax.numpy.array

        A JAX numpy array with the predicted values

    true : jax.numpy.array

        A JAX numpy array with the true values

    wheight : jax.numpy.array

        A JAX numpy array with the weights

    c,q : float

        Hyperparameters

    Returns
    -------
    selft adaptative intersection over union error
    """
    return 1 - (jnp.sum(c * (wheight ** q) * 2 * true * pred) + 1)/(jnp.sum(c * (wheight ** q) * (true + pred + 1)))

#Simple fully connected architecture. Return params and the function for the forward pass
def fconNN(width,activation = jax.nn.relu,key = 0):
    """
    Initialize a Fully Connected Neural Network.
    ----------
    Parameters
    ----------
    width : list of int

        List with the width of each layer

    activation : function

        Activation function

    key : int

        Key for sampling

    Returns
    -------
    dictionary with the initial parameters, forward function and width
    """
    #Initialize parameters with Glorot initialization
    initializer = jax.nn.initializers.glorot_normal()
    key = jax.random.split(jax.random.PRNGKey(key),len(width) - 1) #Seed for initialization
    params = list()
    for key,lin,lout in zip(key,width[:-1],width[1:]):
        W = initializer(key,(lin,lout),jnp.float32)
        B = initializer(key,(1,lout),jnp.float32)
        params.append({'W':W,'B':B})

    #Define function for forward pass
    @jax.jit
    def forward(x,params):
      *hidden,output = params
      for layer in hidden:
        x = activation(x @ layer['W'] + layer['B'])
      return x @ output['W'] + output['B']

    #Return initial parameters and forward function
    return {'params': params,'forward': forward,'width': width}

#Stochastic gradient descent
def sgd(x,y,forward,params,loss,epochs = 100,x_val = None,y_val = None,sa = False,c = 100,q = 2,batches = 1,exp_decay = 0,decay_rate = 0.9,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,key = 0,notebook = False,epoch_print = 1000,trace = False,epoch_trace = 100,trace_file = 'trace.csv'):
    """
    Stochastic gradient descent algorithm
    ----------
    Parameters
    ----------
    x,y : jax.numpy.array

        Input and output data

    forward : function

        Forward function

    params : list

        Initial parameters

    loss : function

        loss function

    epochs : int

        Number of training epochs

    x_val,y_val : jax.numpy.array

        Validation data

    sa : logical

        Whether to consider self-adaptative weights

    c,q : float

        Hyperparameters of self-adaptative weights

    batches : int

        Number of batches

    exp_decay : int

        Number of epochs for exponential decay. Set to 0 for no exponential decay (default)

    decay_rate : float

        Rate of exponential decay. Default 0.9

    lr,b1,b2,eps,eps_root: float

        Hyperparameters of the Adam algorithm. Default lr = 0.001, b1 = 0.9, b2 = 0.999, eps = 1e-08, eps_root = 0.0

    key : int

        Seed for parameters initialization. Default 0

    notebook : logical

        Whether code is being executed in a notebook

    epoch_print : int

        Number of epochs to print training error

    trace : logical

        Whether to trace the algorithm

    epoch_trace : int

        Number of epochs to store trace of algorithm after

    trace_file : str

        File name to save the trace of the algorithm

    Returns
    -------
    list of parameters
    """
    #Key
    key = jax.random.split(jax.random.PRNGKey(key),epochs)

    #Batch size
    bsize = int(math.floor(x.shape[0]/batches))

    #Trace
    if trace:
        tab_trace = {'epoch': [],'time': [],'loss': [],'val_loss': []}

    #Self-adaptative
    if sa:
        params.append({'w': jnp.zeros((y.shape)) + (1/c) ** (1/q)})
        @jax.jit
        def lf(params,x,y):
            return jnp.mean(jax.vmap(lambda true,pred,weight: loss(true,pred,weight,c,q),in_axes = (0,0,0))(forward(x,params[:-1]),y,params[-1]['w']))
        @jax.jit
        def lf_val(params,x,y):
            return jnp.mean(jax.vmap(lambda true,pred: loss(true,pred,1.0,1.0,1.0),in_axes = (0,0))(forward(x,params[:-1]),y))
    else:
        #Loss function
        @jax.jit
        def lf(params,x,y):
            return jnp.mean(jax.vmap(loss,in_axes = (0,0))(forward(x,params),y))
        lf_val = lf

    #Optmizer NN
    if exp_decay != 0:
        lr = optax.exponential_decay(lr,exp_decay,decay_rate)
    optimizer = optax.adam(lr,b1,b2,eps,eps_root)
    opt_state = optimizer.init(params)

    #Training function
    grad_loss = jax.jit(jax.grad(lf,0))
    @jax.jit
    def update(opt_state,params,x,y):
      grads = grad_loss(params,x,y)
      if sa:
          grads[-1]['w'] = - grads[-1]['w']
      updates, opt_state = optimizer.update(grads, opt_state)
      params = optax.apply_updates(params, updates)
      return opt_state,params

    #Train
    t0 = time.time()
    with alive_bar(epochs) as bar:
        for e in range(epochs):
            #Permutate x
            if not sa:
                x = jax.random.permutation(jax.random.PRNGKey(key[e,0]),x,0)
                y = jax.random.permutation(jax.random.PRNGKey(key[e,0]),y,0)
                for b in range(batches):
                    if b < batches - 1:
                        xb = jax.lax.dynamic_slice_in_dim(x,b*bsize,bsize,axis = 0)
                        yb = jax.lax.dynamic_slice_in_dim(y,b*bsize,bsize,axis = 0)
                    else:
                        xb = jax.lax.dynamic_slice_in_dim(x,b*bsize,x.shape[0] - b*bsize,axis = 0)
                        yb = jax.lax.dynamic_slice_in_dim(y,b*bsize,y.shape[0] - b*bsize,axis = 0)
                    opt_state,params = update(opt_state,params,xb,yb)
            else:
                opt_state,params = update(opt_state,params,x,y)
            if not notebook:
                bar()
            if (e % epoch_print == 0 or e % epoch_trace == 0):
                l = lf(params,x,y)
                pl = str(jnp.round(l,10))
                if x_val is not None:
                    vl = lf_val(params,x_val,y_val)
                    pl = pl + ' Val loss: ' + str(jnp.round(vl,10))
                if notebook and e % epoch_print == 0:
                    print('Epoch: ' + str(e) + ' Time: ' + str(jnp.round(time.time() - t0,2)) + ' s Loss: ' + pl)
                if not notebook and e % epoch_print == 0:
                    bar.title("Loss: " + pl)
                if (trace and e % epoch_trace == 0):
                    tab_trace['epoch'] = tab_trace['epoch'] + [e]
                    tab_trace['time'] = tab_trace['time'] + [time.time() - t0]
                    tab_trace['loss'] = tab_trace['loss'] + [l]
                    if x_val is not None:
                        tab_trace['val_loss'] = tab_trace['val_loss'] + [vl]
                    else:
                        tab_trace['val_loss'] = tab_trace['val_loss'] + [-1]

    if (trace and e % epoch_trace != 0):
        tab_trace['epoch'] = tab_trace['epoch'] + [e]
        tab_trace['time'] = tab_trace['time'] + [time.time() - t0]
        tab_trace['loss'] = tab_trace['loss'] + [l]
        if x_val is not None:
            tab_trace['val_loss'] = tab_trace['val_loss'] + [vl]
        else:
            tab_trace['val_loss'] = tab_trace['val_loss'] + [-1]
        tab_trace = pd.DataFrame(tab_trace)
        tab_trace.to_csv(trace_file)

    if sa:
        del params[-1]
    return params


#Fully connected architecture for w-operator characteristic function
def fconNN_wop(width,d,activation = jax.nn.tanh,key = 0,epochs = 1000,train = False):
    """
    Initialize a Fully Connected Neural Network to represent the characteristic function of a W-operator.
    ----------
    Parameters
    ----------
    width : list of int

        List with the width of each layer

    d : int

        Dimension of window

    activation : function

        Activation function

    key : int

        Key for sampling

    epochs : int

        Epochs to pretrain neural network

    train : logical

        Whether to train the neural network to initialise as the identity function

    Returns
    -------
    dictionary with the initial parameters, forward function and width
    """
    #Add first and last layer
    width = [d ** 2] + width + [1]

    #Forward and params
    net = fconNN(width,activation,key)
    forward = lambda x,params: net['forward'](x,params)
    params = net['params']

    #Train
    if train:
        input = jnp.array(list(itertools.product([0, 1], repeat = d ** 2)))
        output = jnp.where(input[:,math.ceil((d ** 2)/2)] == 1,1,0).reshape((input.shape[0],1))
        params = sgd(input,output,forward,params,MSE_SA,sa = True,epochs = epochs,epoch_print = 100)

    #Return initial parameters and forward function
    return {'params': params,'forward': forward,'width': width}

#Apply a morphological layer
def apply_morph_layer(x,type,params,index_x,forward_wop = None,alpha = 5,d = None):
    """
    Apply a morphological layer.
    ----------
    Parameters
    ----------
    x : jax.numpy.array

        A JAX array with images

    type : str

        Names of the operator to apply

    params : jax.numpy.array

        Parameters of the operator

    index_x : jax.numpy.array

        Array with the indexes of f

    forward_wop : function

        Forward function of the W-operator

    alpha : float

        Smoothing parameter

    d : int

        Dimesion of window

    Returns
    -------
    jax.numpy.array with output of layer
    """
    #Apply each operator
    if type != "wop" and type[0] != 'G':
        oper = mp.operator(type,alpha)
        fx = None
        for i in range(params.shape[0]):
            if fx is None:
                fx = oper(x,index_x,params[i,:,:,:]).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            else:
                fx = jnp.append(fx,oper(x,index_x,params[i,:,:,:]).reshape((1,x.shape[0],x.shape[1],x.shape[2])),0)
    elif type[0] == 'G':
        oper = mp.operator(type,alpha)
        fx = None
        for i in range(params.shape[0]):
            if type == 'Gerosion':
                fx_tmp = oper(x,index_x,jnp.append(jnp.zeros((1,params.shape[2],params.shape[3])),jnp.cumsum(jax.nn.sigmoid(params[i,:,:,:]),0),0)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            elif type == 'Gdilation':
                fx_tmp = oper(x,index_x,jnp.append(jnp.cumsum(jax.nn.sigmoid(params[i,:,:,:]),0),jnp.zeros((1,params.shape[2],params.shape[3])) + 1.0,0)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            elif type == 'Ganti-erosion':
                fx_tmp = oper(x,index_x,jnp.append(1.0 - jnp.cumsum(jax.nn.sigmoid(params[i,:,:,:]),0),jnp.zeros((1,params.shape[2],params.shape[3])),0)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            elif type == 'Ganti-dilation':
                fx_tmp = oper(x,index_x,jnp.append(1.0 + jnp.zeros((1,params.shape[2],params.shape[3])),1.0 - jnp.cumsum(jax.nn.sigmoid(params[i,:,:,:]),0),0)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            elif type in ['Gopening','Gclosing','Gasf']:
                fx_tmp = oper(x,index_x,jnp.append(jnp.append(jnp.zeros((1,params.shape[2],params.shape[3])),jnp.cumsum(jax.nn.sigmoid(params[i,:-1,:,:]),0),0),jnp.zeros((1,params.shape[2],params.shape[3])) + 1.0,0)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            elif type == 'Gsupgen':
                b1 = jnp.append(jnp.zeros((1,params.shape[3],params.shape[4])),jnp.cumsum(jax.nn.sigmoid(params[i,0,:,:,:]),0),0)
                b2 = jnp.append(1.0 + jnp.zeros((1,params.shape[3],params.shape[4])),1.0 - jnp.cumsum(jax.nn.sigmoid(params[i,1,:,:,:]),0),0)
                fx_tmp = oper(x,index_x,jnp.minimum(b1,b2),jnp.maximum(b1,b2)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            elif type == 'Ginfgen':
                b1 = jnp.append(1.0 - jnp.cumsum(jax.nn.sigmoid(params[i,0,:,:]),0),jnp.zeros((1,params.shape[3],params.shape[4])),0)
                b2 = jnp.append(jnp.cumsum(jax.nn.sigmoid(params[i,1,:,:]),0),jnp.zeros((1,params.shape[3],params.shape[4])) + 1.0,0)
                fx_tmp = oper(x,index_x,jnp.minimum(b1,b2),jnp.maximum(b1,b2)).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
            if fx is None:
                fx = fx_tmp
            else:
                fx = jnp.append(fx,fx_tmp,0)
    else:
        fx = mp.w_operator_nn(x,index_x,forward_wop,params,d).reshape((1,x.shape[0],x.shape[1],x.shape[2]))
    return fx

#Canonical Morphological NN
def cmnn(type,width,size,shape_x,sample = False,a_init = None,mean = 0.5,sd = 0.1,key = 0,width_wop = None,activation = jax.nn.relu,alpha = 5,m = 255):
    """
    Initialize a Morphological Neural Network
    ----------
    Parameters
    ----------
    type : list of str

        List with the names of the operators to be applied by each layer

    width : list of int

        List with the width of each layer

    size : list of int

        List with the size of the structuring element of each layer

    shape_x : list

        Shape of the input images

    sample : logical

        Whether to sample initial parameters or initialise by a random perturbation of the indentity operator

    a_init : jnp.array

        Initial structuring element

    mean,sd : float

        Mean and standard deviation of Gaussian distribution to sample parameters from and to perturbed the identity operator

    key : int

        Key for sampling

    width_wop : list of int

        List with the width of each layer of the W-operator neural network

    activation : function

        Activation function for W-operator neural network

    alpha : float

        Smoothing parameter

    m : int

        Maximum value of pixel intesity

    Returns
    -------
    dictionary with the initial parameters, forward function, width, size, type and forward funtion of the W-operator
    """
    key = jax.random.split(jax.random.PRNGKey(key),(2*len(width),max(width)))
    k = 0
    forward_wop = None

    #Index window
    index_x = index_array(shape_x)

    #Initialize parameters
    params = list()
    for i in range(len(width)):
        if type[i] in ['sup','inf','complement']:
            params.append(jnp.array(0.0).reshape((1,1,1)))
        elif type[i] == "wop":
            net = fconNN_wop(width_wop,size[i],activation,key[k,0,0])
            k = k + 1
            forward_wop = net['forward']
            params.append(net['params'])
        else:
            if type[i] in ['supgen','infgen','Ssupgen','Sinfgen']:
                for j in range(width[i]):
                    ll = mean + sd*jax.random.normal(jax.random.PRNGKey(key[k,0,j]),shape = (1,1,size[i],size[i]))
                    ul = jnp.abs(sd*jax.random.normal(jax.random.PRNGKey(key[k,1,j]),shape = (1,1,size[i],size[i])))
                    interval = jnp.append(ll,ul,1)
                    k = k + 1
                    if j == 0:
                        p = interval
                    else:
                        p = jnp.append(p,interval,0)
            elif type[i][0] == 'G':
                if type[i] in ['Gsupgen','Ginfgen']:
                    for j in range(width[i]):
                        ll = mean + sd*jax.random.normal(jax.random.PRNGKey(key[k,0,j]),shape = (1,1,m,size[i],size[i]))
                        ul = mean + sd*jax.random.normal(jax.random.PRNGKey(key[k,1,j]),shape = (1,1,m,size[i],size[i]))
                        interval = jnp.append(ll,ul,1)
                        k = k + 1
                        if j == 0:
                            p = interval
                        else:
                            p = jnp.append(p,interval,0)
                else:
                    for j in range(width[i]):
                        s = mean + sd*jax.random.normal(jax.random.PRNGKey(key[k,0,j]),shape = (1,m,size[i],size[i]))
                        k = k + 1
                        if j == 0:
                            p = s
                        else:
                            p = jnp.append(p,s,0)
            else:
                for j in range(width[i]):
                    s = mean + sd*jax.random.normal(jax.random.PRNGKey(key[k,0,0]),shape = (1,1,size[i],size[i]))
                    k = k + 1
                    if j == 0:
                        p = jnp.array(s)
                    else:
                        p = jnp.append(p,s,0)
            params.append(p.astype(jnp.float32))

    #Forward pass
    @jax.jit
    def forward(x,params):
        x = x.reshape((1,x.shape[0],x.shape[1],x.shape[2]))
        for i in range(len(type)):
            #Apply sup and inf
            if type[i] == 'sup':
                x = mp.vmap_sup(x)
            elif type[i] == 'inf':
                x = mp.vmap_inf(x)
            elif type[i] == 'complement':
                x = 1 - x
            else:
                #Apply other layer
                x = apply_morph_layer(x[0,:,:,:],type[i],params[i],index_x,forward_wop,alpha,size[i])
        return x[0,:,:,:]

    #Return initial parameters and forward function
    return {'params': params,'forward': forward,'forward_wop': forward_wop,'type': type,'width': width,'size': size}

#Canonical Morphological NN with FCNN representing strucring elements
def cmnn_fcnn(type,width,width_str,size,shape_x,width_wop = None,activation = jax.nn.relu,sample = True,mean = 0,sd = 0,key = 0,loss = MSE_SA,sa = True,c = 100,q = 2,epochs = 5000,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,notebook = False,epochs_print = 500,alpha = 5,m = 255):
    """
    Initialize a Morphological Neural Network with FCNN representing the structuring elements.
    ----------
    Parameters
    ----------
    type : list of str

        List with the names of the operators to be applied by each layer

    width : list of int

        List with the width of each layer

    width_str : list of int

        List with the width of each layer of the FCNN for structuring elements

    size : list of int

        List with the size of the structuring element of each layer

    shape_x : list

        Shape of the input images

    width_wop : list of int

        List with the width of each layer of the W-operator neural network

    activation : function

        Activation function for fully connected neural network

    sample : logical

        Whether to sample initial parameters or pre-train the FCNN so the operator is close to the identity operator

    mean,sd : float

        Mean and standard deviation of Gaussian distribution to sample parameters from and to perturbed the identity operator

    key : int

        Key for sampling

    loss : function

        Loss function to pre-train FCNN to approximate the identity operator

    sa : logical

        Whether to consider self-adaptative weights

    c,q : float

        Hyperparameters of self-adaptative weights

    epochs : int

        Number of training epochs to pre-train FCNN to approximate the identity operator

    lr,b1,b2,eps,eps_root: float

        Hyperparameters of the Adam algorithm. Default lr = 0.001, b1 = 0.9, b2 = 0.999, eps = 1e-08, eps_root = 0.0

    notebook : logical

        Whether code is being executed in a notebook

    epoch_print : int

        Number of epochs to print training error

    alpha : float

        Smoothing parameter

    m : int
        Maximum value of pixel intensity

    Returns
    -------
    dictionary with the initial parameters, forward function, function to comput structuring elements, width, size, type, forward funtion of the W-operator and forward function of the FCNN
    """
    #Index window
    index_x = index_array(shape_x)
    okey = key

    #Create w to apply structuring FCNN
    unique_size = set(size)
    w = {}
    for d in unique_size:
        w[str(d)] = jnp.array([[x1.tolist(),x2.tolist()] for x1 in jnp.linspace(-jnp.floor(d/2),jnp.floor(d/2),d) for x2 in jnp.linspace(jnp.floor(d/2),-jnp.floor(d/2),d)])

    #Init params
    init_params = None
    forward_wop = None
    if 'wop' in type:
        init_net = cmnn(type,width,size,shape_x,width_wop = width_wop,activation = activation,alpha = alpha) #Initialise
        init_params = init_net['params']
        forward_wop = init_net['forward_wop']

    #Initialize parameters NN
    params = list()
    for i in range(len(width)):
        if type[i] in ['sup','inf','complement','wop']:
            if init_params is None:
                params.append([])
            else:
                params.append(init_params[i])
        else:
            if type[i] in ['supgen','infgen','Ssupgen','Sinfgen']:
                par_layer = list()
                for j in range(width[i]):
                    #Lower
                    nn = fconNN([2] + width_str + [1],activation,key)
                    key = key + 1
                    forward_inner = lambda x,params: nn['forward'](x,params)
                    params_lower = nn['params']
                    #Upper
                    nn = fconNN([2] + width_str + [1],activation,key)
                    key = key + 1
                    params_upper = nn['params']
                    par_layer.append([params_lower,params_upper])
            elif type[i][0] != 'G':
                par_layer = list()
                for j in range(width[i]):
                    nn = fconNN([2] + width_str + [1],activation,key)
                    key = key + 1
                    forward_inner = lambda x,params: nn['forward'](x,params)
                    params_str = nn['params']
                    par_layer.append(params_str)
                params.append(par_layer)
            elif type[i] in ['Gsupgen','Ginfgen']:
                par_layer = list()
                #Lower
                nn1 = fconNN([2] + width_str + [1],activation,key)
                key = key + 1
                nn2 = fconNN([3] + width_str + [1],activation,key)
                key = key + 1
                params_lower = [nn1['params'],nn2['params']]
                #Upper
                nn3 = fconNN([2] + width_str + [1],activation,key)
                key = key + 1
                nn4 = fconNN([3] + width_str + [1],activation,key)
                params_upper = [nn3['params'],nn4['params']]
                par_layer.append([params_lower,params_upper])
            else:
                par_layer = list()
                nn1 = fconNN([2] + width_str + [1],activation,key)
                key = key + 1
                nn2 = fconNN([3] + width_str + [1],activation,key)
                key = key + 1
                par_layer.append([nn1['params'],nn2['params']])
            params.append(par_layer)


    #Compute structuring elements
    nn_str = fconNN([2] + width_str + [1],activation,okey)
    forward_inner = lambda x,params: nn_str['forward'](x,params)
    nn_Gstr = fconNN([3] + width_str + [1],activation,okey)
    forward_Ginner = lambda x,params: nn_Gstr['forward'](x,params)
    @partial(jax.jit, static_argnames=['d'])
    def forward_general(w,params,d):
        ax = forward_inner(w,params[0]).reshape((d,d))
        ftau = lambda tau: jax.nn.elu(forward_Ginner(jnp.append(w,tau + jnp.zeros((w.shape[0],1)),1),params[1])).reshape((d,d)) + 1
        bx = jax.vmap(lambda s: quadgk(ftau,[0., s])[0])((jnp.arange(m) + 1)/m)
        return jax.vmap(lambda x: x + ax)(bx)

    @jax.jit
    def compute_struct(params):
        #Compute for each layer
        struct = list()
        for i in range(len(type)):
            if type[i] in ['sup','inf','complement','wop']:
                struct.append(params[i])
            elif type[i] in ['infgen','supgen','Sinfgen','Ssupgen']:
                par = forward_inner(w[str(size[i])],params[i][0][0]).reshape((size[i],size[i])).transpose().reshape((1,size[i],size[i]))
                par = jnp.append(par,forward_inner(w[str(size[i])],params[i][0][1]).reshape((size[i],size[i])).transpose().reshape((1,size[i],size[i])),0).reshape((1,2,size[i],size[i]))
                for j in range(width[i] - 1):
                    tmp = forward_inner(w[str(size[i])],params[i][j + 1][0]).reshape((size[i],size[i])).transpose().reshape((1,size[i],size[i]))
                    tmp = jnp.append(tmp,forward_inner(w[str(size[i])],params[i][j + 1][1]).reshape((size[i],size[i])).transpose().reshape((1,size[i],size[i])),0).reshape((1,2,size[i],size[i]))
                    par = jnp.append(par,tmp,0)
                struct.append(par)
            elif type[i][0] != 'G':
                par = forward_inner(w[str(size[i])],params[i][0]).reshape((size[i],size[i])).transpose().reshape((1,1,size[i],size[i]))
                for j in range(width[i] - 1):
                    par = jnp.append(par,forward_inner(w[str(size[i])],params[i][j + 1]).reshape((size[i],size[i])).transpose().reshape((1,1,size[i],size[i])),0)
                struct.append(par)
            elif type[i] in ['Gsupgen','Ginfgen']:
                par = forward_general(w[str(size[i])],params[i][0][0],size[i]).reshape((1,m,d,d))
                par = jnp.append(par,forward_general(w[str(size[i])],params[i][0][1],size[i]).reshape((1,m,d,d)),0).reshape((1,2,m,d,d))
                for j in range(width[i] - 1):
                    tmp = forward_general(w[str(size[i])],params[i][j + 1][0],size[i]).reshape((1,m,d,d))
                    tmp = jnp.append(par,forward_general(w[str(size[i])],params[i][j + 1][1],size[i]).reshape((1,m,d,d)),0).reshape((1,2,m,d,d))
                    par = jnp.append(par,tmp,0)
                struct.append(par)
            else:
                par = forward_general(w[str(size[i])],params[i][0],size[i]).reshape((1,m,d,d))
                for j in range(width[i] - 1):
                    tmp = forward_general(w[str(size[i])],params[i][j + 1],size[i]).reshape((1,m,d,d))
                    par = jnp.append(par,tmp,0)
                struct.append(par)
        return struct

    #Forward pass
    #@jax.jit
    def forward(x,params):
        params_array = compute_struct(params)
        x = x.reshape((1,x.shape[0],x.shape[1],x.shape[2]))
        for i in range(len(type)):
            #Apply sup and inf
            if type[i] == 'sup':
                x = mp.vmap_sup(x)
            elif type[i] == 'inf':
                x = mp.vmap_inf(x)
            elif type[i] == 'complement':
                x = 1 - x
            else:
                x = apply_morph_layer(x[0,:,:,:],type[i],params_array[i],index_x,forward_wop,alpha,size[i])
        return x[0,:,:,:]

    #Return initial parameters and forward function
    return {'params': params,'forward': forward,'compute_struct': compute_struct,'forward_wop': forward_wop,'forward_inner': forward_inner,'width': width,'size': size,'type': type}


# Crossover
def crossover_GA(params,weights,parents,N):
    new_params = copy.deepcopy(params)
    for i in range(N):
        for j in range(len(params[i])):
            if isinstance(params[i][j],list):
                for k in range(len(params[i][j])):
                    for l in range(len(params[i][j][k])):
                        if isinstance(new_params[i][j][k][l],list):
                            for m in range(len(new_params[i][j][l])):
                                new_params[i][j][k][l][m]['W'] = weights[i]*params[parents[i,0]][j][k][l][m]['W'] + (1 - weights[i])*params[parents[i,1]][j][k][l][m]['W']
                                new_params[i][j][k][l][m]['B'] = weights[i]*params[parents[i,0]][j][k][l][m]['B'] + (1 - weights[i])*params[parents[i,1]][j][k][l][m]['B']
                        else:
                            new_params[i][j][k][l]['W'] = weights[i]*params[parents[i,0]][j][k][l]['W'] + (1 - weights[i])*params[parents[i,1]][j][k][l]['W']
                            new_params[i][j][k][l]['B'] = weights[i]*params[parents[i,0]][j][k][l]['B'] + (1 - weights[i])*params[parents[i,1]][j][k][l]['B']
            else:
                new_params[i][j] = weights[i]*params[parents[i,0]][j] + (1 - weights[i])*params[parents[i,1]][j]
    return new_params

# Mutate
def mutate_GA(new_params,key_mutate,N,sigma):
    ki = 0
    for i in range(N):
        for j in range(len(new_params[i])):
            if isinstance(new_params[i][j],list):
                for k in range(len(new_params[i][j])):
                    for l in range(len(new_params[i][j][k])):
                        if isinstance(new_params[i][j][k][l],list):
                            for m in range(len(new_params[i][j][l])):
                                new_params[i][j][k][l][m]['W'] = new_params[i][j][k][l][m]['W'] + sigma*jax.random.normal(jax.random.PRNGKey(key_mutate[ki,0]),new_params[i][j][k][l][m]['W'].shape)
                                new_params[i][j][k][l][m]['B'] = new_params[i][j][k][l][m]['B'] + sigma*jax.random.normal(jax.random.PRNGKey(key_mutate[ki,1]),new_params[i][j][k][l][m]['B'].shape)
                                ki = ki + 1
                        else:
                            new_params[i][j][k][l]['W'] = new_params[i][j][k][l]['W'] + sigma*jax.random.normal(jax.random.PRNGKey(key_mutate[ki,0]),new_params[i][j][k][l]['W'].shape)
                            new_params[i][j][k][l]['B'] = new_params[i][j][k][l]['B'] + sigma*jax.random.normal(jax.random.PRNGKey(key_mutate[ki,1]),new_params[i][j][k][l]['B'].shape)
                            ki = ki + 1
            else:
                new_params[i][j] = new_params[i][j] + sigma*jax.random.normal(jax.random.PRNGKey(key_mutate[ki,0]),new_params[i][j].shape)
                ki = ki + 1

# Get loss GA
def get_loss_GA(params,x,y,lf,N):
    loss = jnp.array([])
    for m in range(N):
        loss = jnp.append(loss,lf(params[m],x,y))
    return loss

# Genetic algorithm
def genetic_nn_train(x,y,forward,params,loss,generations = 100,sigma = 0.1,x_val = None,y_val = None,key = 0,notebook = False,gen_print = 1000,trace = False,gen_trace = 100,trace_file = 'trace.csv'):
    """
    Stochastic gradient descent algorithm
    ----------
    Parameters
    ----------
    x,y : jax.numpy.array

        Input and output data

    forward : function

        Forward function

    params : list

        Initial parameters of each initial model

    loss : function

        Loss function

    generations : int

        Number of training generations

    sigma : float

        Mutation standard deviation

    x_val,y_val : jax.numpy.array

        Validation data

    key : int

        Seed for parameters initialization. Default 0

    notebook : logical

        Whether code is being executed in a notebook

    gen_print : int

        Number of generations to print training error

    trace : logical

        Whether to trace the algorithm

    gen_trace : int

        Number of generations to store trace of algorithm after

    trace_file : str

        File name to save the trace of the algorithm

    Returns
    -------
    list of parameters of best model
    """
    #Key
    key = jax.random.split(jax.random.PRNGKey(key),generations)

    # Size of population
    N = len(params) # List of lists

    #Trace
    if trace:
        tab_trace = {'generations': [],'time': [],'loss': [],'val_loss': []}

    #Loss function
    @jax.jit
    def lf(params,x,y):
        return jnp.mean(jax.vmap(loss,in_axes = (0,0))(forward(x,params),y))

    # Compute first generation loss
    gen_loss = get_loss_GA(params,x,y,lf,N)

    #Train
    t0 = time.time()
    with alive_bar(generations) as bar:
        for e in range(generations):
            # Compute probabilities of survival
            prob_survival = 1/gen_loss
            prob_survival = prob_survival/jnp.sum(prob_survival)

            # Crossover
            parents = jax.random.choice(jax.random.PRNGKey(key[e,0]),jnp.arange(N),(N,2))
            weights = jax.random.uniform(jax.random.PRNGKey(key[e,1]),(N,))
            new_params = crossover_GA(params,weights,parents,N)

            # Mutate
            key_mutate = jax.random.split(jax.random.PRNGKey(key[e,0] + key[e,1]),N*1000)
            mutate_GA(new_params,key_mutate,N,sigma)

            # Loss of new models
            offs_loss = get_loss_GA(new_params,x,y,lf,N)

            # Append params
            all_params = params + new_params
            all_loss = jnp.append(gen_loss,offs_loss)
            del params, new_params, gen_loss, offs_loss

            # Keep best N models
            _, best = jax.lax.approx_min_k(all_loss, N)
            params = list()
            for i in best:
                params.append(all_params[i])

            del all_params, all_loss

            # Compute generation loss
            gen_loss = get_loss_GA(params,x,y,lf,N)

            if not notebook:
                bar()
            if (e % gen_print == 0 or e % gen_trace == 0):
                l = jnp.min(gen_loss)
                pl = str(jnp.round(l,10))
                if x_val is not None:
                    vl = lf(params[jnp.where(gen_loss == jnp.min(gen_loss))[0][0]],x_val,y_val)
                    pl = pl + ' Val loss: ' + str(jnp.round(vl,10))
                if notebook and e % gen_print == 0:
                    print('Epoch: ' + str(e) + ' Time: ' + str(jnp.round(time.time() - t0,2)) + ' s Loss: ' + pl)
                if not notebook and e % gen_print == 0:
                    bar.title("Loss: " + pl)
                if (trace and e % gen_trace == 0):
                    tab_trace['generations'] = tab_trace['generations'] + [e]
                    tab_trace['time'] = tab_trace['time'] + [time.time() - t0]
                    tab_trace['loss'] = tab_trace['loss'] + [l]
                    if x_val is not None:
                        tab_trace['val_loss'] = tab_trace['val_loss'] + [vl]
                    else:
                        tab_trace['val_loss'] = tab_trace['val_loss'] + [-1]

    if trace:
        tab_trace['generations'] = tab_trace['generations'] + [e]
        tab_trace['time'] = tab_trace['time'] + [time.time() - t0]
        tab_trace['loss'] = tab_trace['loss'] + [l]
        if x_val is not None:
            vl = lf(params[jnp.where(gen_loss == jnp.min(gen_loss))[0][0]],x_val,y_val)
            tab_trace['val_loss'] = tab_trace['val_loss'] + [vl]
        else:
            tab_trace['val_loss'] = tab_trace['val_loss'] + [-1]
        tab_trace = pd.DataFrame(tab_trace)
        tab_trace.to_csv(trace_file)

    return params[jnp.where(gen_loss == jnp.min(gen_loss))[0][0]]
