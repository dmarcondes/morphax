#SLDA for training DMNN
def slda(x,y,x_val,y_val,forward,params,loss,epochs_nn,epochs_slda,sample_neigh,mask = None,sa = False,c = 100,q = 2,batches = 1,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,key = 0,notebook = False,epoch_print = 100):
    #Find out width,size, type and calculate probabilities
    width = []
    size = []
    prob = []
    type = []
    for i in range(len(params)):
        width = width + [params[i].shape[0]]
        size = size + [params[i].shape[2]]
        if params[i].shape[2] > 1:
            prob  = prob + [params[i].shape[0] * (params[i].shape[2] ** 2)]
        else:
            prob  = prob + [0]
        if params[i].shape[1] == 2:
            type = type + ['gen']
            prob[-1] = 2*prob[-1]
        else:
            type = type + ['other']

    prob = [x/sum(prob) for x in prob]

    #Current error
    current_error = loss(forward(x_val,params),y_val).tolist()

    #Epochs of SLDA
    for e in range(epochs_slda):
        print("Epoch SLDA " + str(e) + ' Current validation error: ' + str(jnp.round(current_error,6)))
        min_error = jnp.inf
        #Sample neighbors
        for n in range(sample_neigh):
            print("Sample neighbor " + str(n) + ' Min local validation error :' + str(jnp.round(min_error,6)))
            #Sample layer
            layer = np.random.choice(list(range(len(width))),1,p = prob)[0]
            #Sample node
            node = np.random.choice(list(range(width[layer])),1)[0]
            #Position
            pos = np.random.choice(list(range(size[layer] ** 2)),1)[0]
            pos = [math.floor(pos/size[layer]),pos - (math.floor(pos/size[layer]))*size[layer]]
            #Limit of interval
            if type[layer] == 'gen':
                limit = np.random.choice([0,1],1)[0]
            else:
                limit = 0
            #New mask
            new_mask = mask
            new_mask[layer] = new_mask[layer].at[node,limit,pos[0],pos[1]].set(jnp.abs(1 - new_mask[layer][node,limit,pos[0],pos[1]]))

            #Train
            res_neigh = train_morph(x,y,forward,params,loss,new_mask,sa,c,q,epochs_nn,batches,lr,b1,b2,eps,eps_root,key,notebook,epoch_print)

            #Val error
            error_neigh = loss(forward(x_val,res_neigh),y_val).tolist()

            #Store is best
            if error_neigh < min_error:
                min_error = error_neigh
                min_mask = new_mask
                min_params = res_neigh

        #Update
        mask = min_mask
        params = min_params
        current_error = min_error

    return {'params': params,'mask': mask}

#Name mask
def name_mask(mask):
    n = []
    for i in range(len(mask)):
        n = n + [' - '] + mask[i].astype(jnp.int32).reshape((1,mask[i].shape[0] * mask[i].shape[1])).tolist()[0]

    return "".join(str(element) for element in n)

#Lista valid neighbors of a window
def list_neighbors(mask):
    #Store valids
    order = []
    row = []
    col = []

    #Test each change
    for m in range(len(mask)):
        for i in range(mask[m].shape[0]):
            for j in range(mask[m].shape[1]):
                if mask[m][i,j] == 1:
                    add = True
                    tot = 0
                    for ip in [i - 1,i,i + 1]:
                        for jp in [j - 1,j,j + 1]:
                            if ip >= 0 and ip < mask[m].shape[0] and jp >= 0 and jp < mask[m].shape[1] and (ip == i or jp == j) and not (jp == j and ip == i):
                                if mask[m][ip,jp] == 1:
                                    tot = tot + 1
                                    if not ((mask[m][ip - 1,jp] == 1 and ip-1 >= 0 and ip - 1 != i) or (mask[m][ip+1,jp] == 1 and ip+1 < mask[m].shape[0] and ip + 1 != i) or (mask[m][ip,jp-1] == 1 and jp-1 >= 0 and jp - 1 != j) or (mask[m][ip,jp+1] == 1 and jp+1 < mask[m].shape[1] and jp + 1 != j)):
                                        add = False
                    if add and tot > 0:
                        order = order + [m]
                        row = row + [i]
                        col = col + [j]
                else:
                    if (mask[m][i-1,j] == 1 and i-1 >= 0) or (mask[m][i+1,j] == 1 and i+1 < mask[m].shape[0]) or (mask[m][i,j-1] == 1 and j-1 >= 0) or (mask[m][i,j+1] == 1 and j+1 < mask[m].shape[1]):
                        order = order + [m]
                        row = row + [i]
                        col = col + [j]

    return np.array([order,row,col]).transpose()

#SLDA for window lwarning
def slda_window(x,y,x_val,y_val,type,width,size,shape_x,loss,epochs_slda = 1,sample = -1,iter = False,loss_val = None,width_str = None,epochs = 100,h = 1/100,mask = None,key = 0,init = 'random',width_wop = None,activation = jax.nn.tanh,sa = False,c = 100,q = 2,batches = 1,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,notebook = False,epoch_print = 100):
    #Loss validation
    if loss_val is None:
        loss_val = loss

    #Initialize mask
    if mask is None:
        mask = list()
        for i in range(len(width)):
            if type[i] in ['sup','inf','complement']:
                mask.append(np.array(0.0))
            else:
                m = jnp.zeros((size[i],size[i]))
                l = math.floor(size[i]/2)
                m = m.at[l,l].set(1.0)
                mask.append(m)

    #Train initial model
    print('\n--------------------------\n Initial model \n--------------------------\n')
    if iter:
        #Broken
        initial_net = cmnn_iter(type,width,width_str,size,shape_x,h,x,mask,width_wop,activation,key,init,loss = MSE_SA,sa = True,c = 100,q = 2,epochs = 20000,batches = 1,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,notebook = False)
    else:
        initial_net = cmnn(x,type,width,size,shape_x,h,mask,key,init,width_wop,activation)
    params = initial_net['params']
    forward = initial_net['forward']
    for rate in lr:
        params = train_morph(x,y,forward,params,loss,sa,c,q,epochs,batches,rate,b1,b2,eps,eps_root,key,notebook,epoch_print)

    #Current point
    current_error = loss_val(y_val,forward(x_val,params))
    current_params = params
    current_forward = forward
    current_mask = mask
    current_forward_wop = initial_net['forward_wop']
    masks_visited = [name_mask(mask)]
    loss_masks_visited = [current_error.tolist()]

    #Current epoch
    current_error_epoch = current_error
    current_params_epoch = params
    current_forward_epoch = forward
    current_mask_epoch = mask
    current_forward_wop_epoch = initial_net['forward_wop']

    #Best
    best_error = current_error
    best_params = params
    best_forward = forward
    best_mask = mask
    best_forward_wop = initial_net['forward_wop']

    #Start SLDA
    for e in range(epochs_slda):
        print('\n--------------------------\n Epoch ' + str(e) + ' Current validation loss: ' + str(round(current_error_epoch,6)) + ' \n--------------------------\n')
        #List neighbors
        lneigh = list_neighbors(current_mask)

        #Sample neighbors
        if sample > 0 and sample < lneigh.shape[0]:
            lneigh = lneigh[np.random.choice(lneigh.shape[0],sample,replace=False),:]
        else:
            lneigh = lneigh[np.random.choice(lneigh.shape[0],lneigh.shape[0],replace=False),:]

        #Train each neighbor
        for n in range(lneigh.shape[0]):
            #Update mask
            del mask
            mask = current_mask.copy()
            mask[lneigh[n,0]] = mask[lneigh[n,0]].at[lneigh[n,1],lneigh[n,2]].set(np.abs(1 - mask[lneigh[n,0]][lneigh[n,1],lneigh[n,2]]))

            if not name_mask(mask) in masks_visited:
                #Initialize cmnn
                if iter:
                    #Broken
                    net = cmnn_iter(type,width,width_str,size,shape_x,h,x,mask,width_wop,activation,key,init,loss = MSE_SA,sa = True,c = 100,q = 2,epochs = 20000,batches = 1,lr = 0.001,b1 = 0.9,b2 = 0.999,eps = 1e-08,eps_root = 0.0,notebook = False)
                else:
                    net = cmnn(x,type,width,size,shape_x,h,mask,key,init,width_wop,activation)

                #Inititalize params
                params = current_params
                forward = net['forward']
                for rate in lr:
                    params = train_morph(x,y,forward,params,loss,sa,c,q,epochs,batches,rate,b1,b2,eps,eps_root,key,notebook,epoch_print)

                #Save
                error_mask = loss_val(y_val,forward(x_val,params))
                masks_visited = masks_visited + [name_mask(mask)]
                loss_masks_visited = loss_masks_visited + [error_mask.tolist()]
            else:
                error_mask = loss_masks_visited[name_mask(mask) == masks_visited]

            print('Neighbor '+ str(n) + ' Validation loss: ' + str(round(error_mask,6)))


            if error_mask < current_error_epoch:
                current_error_epoch = error_mask
                current_params_epoch = params
                current_forward_epoch = forward
                current_mask_epoch = mask
                current_forward_wop_epoch = net['forward_wop']

        current_error = current_error_epoch
        current_params = current_params_epoch
        current_forward = current_forward_epoch
        current_mask = current_mask_epoch
        current_forward_wop = current_forward_wop_epoch

        if current_error < best_error:
            best_error = current_error
            best_params = current_params
            best_forward = current_forward
            best_mask = current_mask
            best_forward_wop = current_forward_wop

    return {"params": best_params,"forward": best_forward,'mask': best_mask,'forward_wop': best_forward_wop,'val_loss': best_error,'masks_visisted': masks_visited,'loss_masks_visited': loss_masks_visited}
